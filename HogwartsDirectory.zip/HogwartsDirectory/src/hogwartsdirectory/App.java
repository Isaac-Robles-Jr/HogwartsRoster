package hogwartsdirectory;

import controller.HRController;

/*
Assignment: App
Group Members: Isaac Robles Jr. & Pablo Torres
ID: ixr5066
*/

public class App {
    
    public static void main(String[] args) {
        HRController ctrl = new HRController();
    }
}