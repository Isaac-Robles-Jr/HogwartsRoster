package model;

/*
Assignment: HogwartsRoster
Group Members: Isaac Robles Jr. & Pablo Torres
ID: ixr5066
 */
import java.util.ArrayList;

public class HRModel {

    private final ArrayList<HRModelEntry> entryList;
    private final ArrayList<HRModelEntry> entryGList;
    private final ArrayList<HRModelEntry> entrySList;
    private final ArrayList<HRModelEntry> entryHList;
    private final ArrayList<HRModelEntry> entryRList;

    public HRModel() {
        entryList = new ArrayList<>();
        entryGList = new ArrayList<>();
        entrySList = new ArrayList<>();
        entryHList = new ArrayList<>();
        entryRList = new ArrayList<>();
        addEntriesToList();
        addEntriesToGList();
        addEntriesToSList();
        addEntriesToHList();
        addEntriesToRList();
    }

    /*
    The addEntriesToList() method puts some default entries in to populate the database.
     */
    private void addEntriesToList() {
        getListOfAllEntries().add(new HRModelEntry(1, "Harry", "Potter", "Gryffindor", "Alumni", 100));
        getListOfAllEntries().add(new HRModelEntry(2, "Hermione", "Granger", "Gryffindor", "Alumni", 60));
        getListOfAllEntries().add(new HRModelEntry(3, "Ron", "Weasley", "Gryffindor", "Alumni", 45));
        getListOfAllEntries().add(new HRModelEntry(4, "Draco", "Malfoy", "Slytherin", "Alumni", 10));
        getListOfAllEntries().add(new HRModelEntry(5, "Albus", "Dumbledore", "Gryffindor", "Headmaster", 100));
        getListOfAllEntries().add(new HRModelEntry(6, "Minerva", "McGonagall", "Gryffindor", "Professor", 100));
        getListOfAllEntries().add(new HRModelEntry(7, "Rubeus", "Hagrid", "Gryffindor", "Groundskeeper", 0));
        getListOfAllEntries().add(new HRModelEntry(8, "Arthur", "Weasley", "Gryffindor", "Alumni", 55));
        getListOfAllEntries().add(new HRModelEntry(9, "Molly", "Weasley", "Gryffindor", "Alumni", 60));
        getListOfAllEntries().add(new HRModelEntry(10, "Sirius", "Black", "Gryffindor", "Alumni", 5));
        getListOfAllEntries().add(new HRModelEntry(11, "Remus", "Lupin", "Gryffindor", "Alumni", 5));
        getListOfAllEntries().add(new HRModelEntry(12, "Peter", "Pettigrew", "Gryffindor", "Alumni", 0));
        getListOfAllEntries().add(new HRModelEntry(13, "James", "Potter", "Gryffindor", "Alumni", 30));
        getListOfAllEntries().add(new HRModelEntry(14, "Lily", "Evans", "Gryffindor", "Alumni", 80));
        getListOfAllEntries().add(new HRModelEntry(15, "Bill", "Weasley", "Gryffindor", "Alumni", 90));
        getListOfAllEntries().add(new HRModelEntry(16, "Charlie", "Weasley", "Gryffindor", "Alumni", 80));
        getListOfAllEntries().add(new HRModelEntry(17, "Percy", "Weasley", "Gryffindor", "Alumni", 80));
        getListOfAllEntries().add(new HRModelEntry(18, "Fred", "Weasley", "Gryffindor", "Alumni", 1));
        getListOfAllEntries().add(new HRModelEntry(19, "George", "Weasley", "Gryffindor", "Alumni", 1));
        getListOfAllEntries().add(new HRModelEntry(20, "Seamus", "Finnigan", "Gryffindor", "Alumni", 15));
        getListOfAllEntries().add(new HRModelEntry(21, "Neville", "Longbottom", "Gryffindor", "Alumni", 60));
        getListOfAllEntries().add(new HRModelEntry(22, "Ginny", "Weasley", "Gryffindor", "Alumni", 25));
        getListOfAllEntries().add(new HRModelEntry(23, "Cedric", "Diggory", "Hufflepuff", "Alumni", 100));
        getListOfAllEntries().add(new HRModelEntry(24, "Newt", "Scamander", "Hufflepuff", "Alumni", 100));
        getListOfAllEntries().add(new HRModelEntry(25, "Teddy", "Lupin", "Hufflepuff", "Alumni", 100));
        getListOfAllEntries().add(new HRModelEntry(26, "Filius", "Flitwick", "Ravenclaw", "Professor", 100));
        getListOfAllEntries().add(new HRModelEntry(27, "Gilderoy", "Lockhart", "Ravenclaw", "Professor", 0));
        getListOfAllEntries().add(new HRModelEntry(28, "Cho", "Chang", "Ravenclaw", "Alumni", 5));
        getListOfAllEntries().add(new HRModelEntry(29, "Luna", "Lovegood", "Ravenclaw", "Alumni", 90));
        getListOfAllEntries().add(new HRModelEntry(30, "Horace", "Slughorn", "Slytherin", "Professor", 30));
        getListOfAllEntries().add(new HRModelEntry(31, "Phineas", "Black", "Slytherin", "Alumni", 5));
        getListOfAllEntries().add(new HRModelEntry(32, "Tom", "Riddle", "Slytherin", "Alumni", 100));
        getListOfAllEntries().add(new HRModelEntry(33, "Dolores", "Umbridge", "Slytherin", "Professor", 0));
        getListOfAllEntries().add(new HRModelEntry(34, "Regulus", "Black", "Slytherin", "Alumni", 0));
        getListOfAllEntries().add(new HRModelEntry(35, "Severus", "Snape", "Slytherin", "Professor", 100));
        getListOfAllEntries().add(new HRModelEntry(36, "Bellatrix", "Black", "Slytherin", "Alumni", 0));
        getListOfAllEntries().add(new HRModelEntry(37, "Lucius", "Malfoy", "Slytherin", "Alumni", 5));
        getListOfAllEntries().add(new HRModelEntry(38, "Narcissa", "Black", "Slytherin", "Alumni", 0));
        getListOfAllEntries().add(new HRModelEntry(39, "Vincent", "Crabbe", "Slytherin", "Alumni", 35));
        getListOfAllEntries().add(new HRModelEntry(40, "Gregory", "Goyle", "Slytherin", "Alumni", 40));

    }

    private void addEntriesToGList() {
        getListOfGEntries().add(new HRModelEntry(1, "Harry", "Potter", "Gryffindor", "Alumni", 50));
        getListOfGEntries().add(new HRModelEntry(2, "Hermione", "Granger", "Gryffindor", "Alumni", 60));
        getListOfGEntries().add(new HRModelEntry(3, "Ron", "Weasley", "Gryffindor", "Alumni", 45));
        getListOfGEntries().add(new HRModelEntry(5, "Albus", "Dumbledore", "Gryffindor", "Headmaster", 100));
        getListOfGEntries().add(new HRModelEntry(6, "Minerva", "McGonagall", "Gryffindor", "Professor", 100));
        getListOfGEntries().add(new HRModelEntry(7, "Rubeus", "Hagrid", "Gryffindor", "Groundskeeper", 0));
        getListOfGEntries().add(new HRModelEntry(8, "Arthur", "Weasley", "Gryffindor", "Alumni", 50));
        getListOfGEntries().add(new HRModelEntry(9, "Molly", "Weasley", "Gryffindor", "Alumni", 60));
        getListOfGEntries().add(new HRModelEntry(10, "Sirius", "Black", "Gryffindor", "Alumni", 5));
        getListOfGEntries().add(new HRModelEntry(11, "Remus", "Lupin", "Gryffindor", "Alumni", 5));
        getListOfGEntries().add(new HRModelEntry(12, "Peter", "Pettigrew", "Gryffindor", "Alumni", 0));
        getListOfGEntries().add(new HRModelEntry(13, "James", "Potter", "Gryffindor", "Alumni", 30));
        getListOfGEntries().add(new HRModelEntry(14, "Lily", "Evans", "Gryffindor", "Alumni", 80));
        getListOfGEntries().add(new HRModelEntry(15, "Bill", "Weasley", "Gryffindor", "Alumni", 90));
        getListOfGEntries().add(new HRModelEntry(16, "Charlie", "Weasley", "Gryffindor", "Alumni", 80));
        getListOfGEntries().add(new HRModelEntry(17, "Percy", "Weasley", "Gryffindor", "Alumni", 80));
        getListOfGEntries().add(new HRModelEntry(18, "Fred", "Weasley", "Gryffindor", "Alumni", 1));
        getListOfGEntries().add(new HRModelEntry(19, "George", "Weasley", "Gryffindor", "Alumni", 1));
        getListOfGEntries().add(new HRModelEntry(20, "Seamus", "Finnigan", "Gryffindor", "Alumni", 15));
        getListOfGEntries().add(new HRModelEntry(21, "Neville", "Longbottom", "Gryffindor", "Alumni", 60));
        getListOfGEntries().add(new HRModelEntry(22, "Ginny", "Weasley", "Gryffindor", "Alumni", 25));
    }

    private void addEntriesToRList() {
        getListOfREntries().add(new HRModelEntry(26, "Filius", "Flitwick", "Ravenclaw", "Professor", 100));
        getListOfREntries().add(new HRModelEntry(27, "Gilderoy", "Lockhart", "Ravenclaw", "Professor", 0));
        getListOfREntries().add(new HRModelEntry(28, "Cho", "Chang", "Ravenclaw", "Alumni", 5));
        getListOfREntries().add(new HRModelEntry(29, "Luna", "Lovegood", "Ravenclaw", "Alumni", 90));
    }

    private void addEntriesToHList() {
        getListOfHEntries().add(new HRModelEntry(23, "Cedric", "Diggory", "Hufflepuff", "Alumni", 10));
        getListOfHEntries().add(new HRModelEntry(24, "Newt", "Scamander", "Hufflepuff", "Alumni", 100));
        getListOfHEntries().add(new HRModelEntry(25, "Teddy", "Lupin", "Hufflepuff", "Alumni", 100));
    }

    private void addEntriesToSList() {
        getListOfSEntries().add(new HRModelEntry(4, "Draco", "Malfoy", "Slytherin", "Alumni", 10));
        getListOfSEntries().add(new HRModelEntry(30, "Horace", "Slughorn", "Slytherin", "Professor", 30));
        getListOfSEntries().add(new HRModelEntry(31, "Phineas", "Black", "Slytherin", "Alumni", 5));
        getListOfSEntries().add(new HRModelEntry(32, "Tom", "Riddle", "Slytherin", "Alumni", 100));
        getListOfSEntries().add(new HRModelEntry(33, "Dolores", "Umbridge", "Slytherin", "Professor", 0));
        getListOfSEntries().add(new HRModelEntry(34, "Regulus", "Black", "Slytherin", "Alumni", 0));
        getListOfSEntries().add(new HRModelEntry(35, "Severus", "Snape", "Slytherin", "Professor", 100));
        getListOfSEntries().add(new HRModelEntry(36, "Bellatrix", "Black", "Slytherin", "Alumni", 0));
        getListOfSEntries().add(new HRModelEntry(37, "Lucius", "Malfoy", "Slytherin", "Alumni", 5));
        getListOfSEntries().add(new HRModelEntry(38, "Narcissa", "Black", "Slytherin", "Alumni", 0));
        getListOfSEntries().add(new HRModelEntry(39, "Vincent", "Crabbe", "Slytherin", "Alumni", 35));
        getListOfSEntries().add(new HRModelEntry(40, "Gregory", "Goyle", "Slytherin", "Alumni", 40));
    }

    /*
    The getListOfStudents() method simply returns the entryList to allow the use of entryList's methods
     */
    public ArrayList<HRModelEntry> getListOfAllEntries() {
        return entryList;
    }

    public ArrayList<HRModelEntry> getListOfGEntries() {
        return entryGList;
    }

    public ArrayList<HRModelEntry> getListOfSEntries() {
        return entrySList;
    }

    public ArrayList<HRModelEntry> getListOfHEntries() {
        return entryHList;
    }

    public ArrayList<HRModelEntry> getListOfREntries() {
        return entryRList;
    }

    /*
    The allEntries() method takes in the JTextFields from the addWindow and checks to see if that entry exists in entryList.
     */
    public boolean allEntries(String fName, String lName, String house, String year, String points) {
        for (int i = 0; i < entryList.size() - 1; i++) {
            if ((fName.equalsIgnoreCase(entryList.get(i).getfName())
                    && lName.equalsIgnoreCase(entryList.get(i).getlName())
                    && house.equalsIgnoreCase(entryList.get(i).getHouse())
                    && year.equalsIgnoreCase(entryList.get(i).getYear())
                    && points.equalsIgnoreCase(Integer.toString(entryList.get(i).getPointsContributed()))) == true) {
                return true;
            }
        }

        return false;
    }
}
