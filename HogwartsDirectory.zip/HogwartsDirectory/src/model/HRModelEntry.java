package model;

/*
Assignment: HogwartsRoster
Group Members: Isaac Robles Jr. & Pablo Torres
ID: ixr5066
 */
public class HRModelEntry {

    int entryID;
    String fName;
    String lName;
    String house;
    String affilation;
    int pointsContributed;

    public HRModelEntry(int entryID, String fName, String lName, String house, String affilation, int pointsContributed) {
        this.entryID = entryID;
        this.fName = fName;
        this.lName = lName;
        this.house = house;
        this.affilation = affilation;
        this.pointsContributed = pointsContributed;
    }

    public int getEntryID() {
        return entryID;
    }

    public String getfName() {
        return fName;
    }

    public String getlName() {
        return lName;
    }

    public String getHouse() {
        return house;
    }

    public String getAffiliation() {
        return affilation;
    }

    public int getPointsContributed() {
        return pointsContributed;
    }
}
