package model;

/*
Assignment: HogwartsRoster
Group Members: Isaac Robles Jr. & Pablo Torres
ID: ixr5066
 */
public class HRModelEntry {

    int entryID;
    String fName;
    String lName;
    String house;
    String year;
    int pointsContributed;

    public HRModelEntry(int entryID, String fName, String lName, String house, String year, int pointsContributed) {
        this.entryID = entryID;
        this.fName = fName;
        this.lName = lName;
        this.house = house;
        this.year = year;
        this.pointsContributed = pointsContributed;
    }

    public int getStudentID() {
        return entryID;
    }

    public String getfName() {
        return fName;
    }

    public String getlName() {
        return lName;
    }

    public String getHouse() {
        return house;
    }

    public String getYear() {
        return year;
    }

    public int getPointsContributed() {
        return pointsContributed;
    }
}
