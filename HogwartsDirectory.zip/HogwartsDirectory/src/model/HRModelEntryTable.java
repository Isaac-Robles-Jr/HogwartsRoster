package model;

/*
Assignment: HogwartsRoster
Group Members: Isaac Robles Jr. & Pablo Torres
ID: ixr5066
 */
import model.HRModelEntry;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

public class HRModelEntryTable extends AbstractTableModel {

    private static final String[] COLUMN_NAMES = {"EntryID", "First Name", "Last Name", "House", "Affiliation", "Points"};
    private final ArrayList<HRModelEntry> entryList;

    public HRModelEntryTable(ArrayList<HRModelEntry> entryList) {
        this.entryList = entryList;
        for (int i = 0; i < entryList.size() - 1; i++) {
            for (int j = 0; j < 6; j++) {
                if (j == 0) {
                    setValueAt(entryList.get(i).getEntryID(), j, i);
                } else if (j == 1) {
                    setValueAt(entryList.get(i).getfName(), j, i);
                } else if (j == 2) {
                    setValueAt(entryList.get(i).getlName(), j, i);
                } else if (j == 3) {
                    setValueAt(entryList.get(i).getHouse(), j, i);
                } else if (j == 4) {
                    setValueAt(entryList.get(i).getAffiliation(), j, i);
                } else if (j == 5) {
                    setValueAt(entryList.get(i).getPointsContributed(), j, i);
                }
            }
        }
    }

    @Override
    public String getColumnName(int col) {
        return COLUMN_NAMES[col];
    }

    public void setValueAt(HRModelEntry aValue, int rowIndex, int columnIndex) {
        fireTableCellUpdated(rowIndex, columnIndex);
    }

    @Override
    public int getRowCount() {
        return entryList.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMN_NAMES.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if (columnIndex == 0) {
            return entryList.get(rowIndex).getEntryID();
        } else if (columnIndex == 1) {
            return entryList.get(rowIndex).getfName();
        } else if (columnIndex == 2) {
            return entryList.get(rowIndex).getlName();
        } else if (columnIndex == 3) {
            return entryList.get(rowIndex).getHouse();
        } else if (columnIndex == 4) {
            return entryList.get(rowIndex).getAffiliation();
        } else if (columnIndex == 5) {
            return entryList.get(rowIndex).getPointsContributed();
        }

        return "Item does not exist";
    }
}
