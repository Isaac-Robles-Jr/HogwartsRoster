package view;

/*
Assignment: HogwartsRoster
Group Members: Isaac Robles Jr. & Pablo Torres
ID: ixr5066
 */
import model.HRModelEntry;
import model.HRModelEntryTable;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class HRView extends JFrame {

    //Icon variables
    private final ImageIcon allIcon = new ImageIcon("src/resources/All.jpg");
    private final ImageIcon gIcon = new ImageIcon("src/resources/Gryffindor.jpg");
    private final ImageIcon sIcon = new ImageIcon("src/resources/Slytherin.jpg");
    private final ImageIcon hIcon = new ImageIcon("src/resources/Hufflepuff.jpg");
    private final ImageIcon rIcon = new ImageIcon("src/resources/Ravenclaw.jpg");

    //Button variables
    private final JButton allButton = new JButton(allIcon);
    private final JButton gButton = new JButton(gIcon);
    private final JButton sButton = new JButton(sIcon);
    private final JButton hButton = new JButton(hIcon);
    private final JButton rButton = new JButton(rIcon);
    private final JButton addButton = new JButton("Add");
    private final JButton editButton = new JButton("Edit");
    private final JButton deleteButton = new JButton("Delete");
    private final JButton exitButton = new JButton("Exit");

    //Label variables
    private final JLabel notificationLabel = new JLabel();

    //Table and ScrollPane variables
    private JTable entryTable;
    private final JScrollPane scrollTable;

    //Panel variables
    private final JPanel studentPanel;
    private final JPanel topButtonPanel;
    private final JPanel botButtonPanel;

    public HRView(ArrayList<HRModelEntry> studentList) {
        setTitle("Hogwarts Directory");
        setSize(700, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        topButtonPanel = new JPanel(new FlowLayout());
        topButtonPanel.add(allButton);
        topButtonPanel.add(gButton);
        topButtonPanel.add(hButton);
        topButtonPanel.add(rButton);
        topButtonPanel.add(sButton);

        entryTable = new JTable(new HRModelEntryTable(studentList));
        entryTable.setPreferredScrollableViewportSize(new Dimension(450, 50));
        entryTable.setFillsViewportHeight(true);

        scrollTable = new JScrollPane(entryTable);
        scrollTable.setVisible(true);
        scrollTable.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        add(scrollTable);

        studentPanel = new JPanel(new BorderLayout());
        studentPanel.add(scrollTable, BorderLayout.CENTER);
        studentPanel.add(notificationLabel, BorderLayout.SOUTH);

        botButtonPanel = new JPanel(new FlowLayout());
        botButtonPanel.add(addButton);
        botButtonPanel.add(editButton);
        botButtonPanel.add(deleteButton);
        botButtonPanel.add(exitButton);

        setContentPane(new JPanel(new BorderLayout()));
        getContentPane().add(topButtonPanel, BorderLayout.NORTH);
        getContentPane().add(studentPanel, BorderLayout.CENTER);
        getContentPane().add(botButtonPanel, BorderLayout.SOUTH);
        setResizable(false);
    }
    
    /*
    Below are getters for buttons for the actionListeners
    */
    public JButton getAddButton() {
        return addButton;
    }

    public JButton getEditButton() {
        return editButton;
    }

    public JButton getDeleteButton() {
        return deleteButton;
    }

    public JButton getExitButton() {
        return exitButton;
    }

    public JButton getAllButton() {
        return allButton;
    }

    public JButton getGButton() {
        return gButton;
    }

    public JButton getSButton() {
        return sButton;
    }

    public JButton getHButton() {
        return hButton;
    }

    public JButton getRButton() {
        return rButton;
    }

    public JTable getTable() {
        return entryTable;
    }

    public JLabel getLabel() {
        return notificationLabel;
    }
}
