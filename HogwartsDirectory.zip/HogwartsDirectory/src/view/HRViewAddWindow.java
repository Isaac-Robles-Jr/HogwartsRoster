package view;

/*
Assignment: HogwartsRoster
Group Members: Isaac Robles Jr. & Pablo Torres
ID: ixr5066
 */
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class HRViewAddWindow extends JFrame {

    //Panel variable
    private final JPanel entryPanel;
    private final JPanel botButtonPanel;

    //Button variable
    private final JButton doneButton;
    private final JButton sortButton;

    //TextField variables
    private final JTextField firstName = new JTextField(15);
    private final JTextField lastName = new JTextField(15);
    private final JTextField houseName = new JTextField(15);
    private final JTextField affiliation = new JTextField(15);
    private final JTextField pointsNum = new JTextField(15);

    //Label variables
    private final JLabel notificationLabel = new JLabel();

    public HRViewAddWindow() {
        setTitle("Edit Window");
        setSize(750, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        doneButton = new JButton("Done");
        sortButton = new JButton("Sorting Hat");

        entryPanel = new JPanel(new GridLayout(6, 1));
        entryPanel.add(new JLabel("First Name"));
        entryPanel.add(firstName);
        entryPanel.add(new JLabel("Last Name"));
        entryPanel.add(lastName);
        entryPanel.add(new JLabel("House"));
        entryPanel.add(houseName);
        entryPanel.add(new JLabel("Affilation"));
        entryPanel.add(affiliation);
        entryPanel.add(new JLabel("Points"));
        entryPanel.add(pointsNum);
        entryPanel.add(notificationLabel);

        botButtonPanel = new JPanel(new FlowLayout());
        botButtonPanel.add(sortButton);
        botButtonPanel.add(doneButton);

        setContentPane(new JPanel(new BorderLayout()));
        getContentPane().add(entryPanel, BorderLayout.CENTER);
        getContentPane().add(botButtonPanel, BorderLayout.SOUTH);
        setResizable(false);
    }

    public JButton getDoneButton() {
        return doneButton;
    }

    public JButton getSortButton() {
        return sortButton;
    }
    
    /*
    The follow methods contains getter and setters of all text fields the user can interact with. These
    are used to check for certain things such as correct input, or to change the entry like is done with the sortingHat() method.
    */

    public String getFirstNameText() {
        return firstName.getText();
    }

    public void setFirstNameText(String str) {
        firstName.setText(str);
    }

    public String getLastNameText() {
        return lastName.getText();
    }

    public void setLastNameText(String str) {
        lastName.setText(str);
    }

    public String getHouseNameText() {
        return houseName.getText();
    }

    public void setHouseNameText(String str) {
        houseName.setText(str);
    }

    public String getAffiliationText() {
        return affiliation.getText();
    }

    public void setAffiliationText(String str) {
        affiliation.setText(str);
    }

    public String getPointsNumText() {
        return pointsNum.getText();
    }

    public void setPointsNumText(String str) {
        pointsNum.setText(str);
    }

    public void setNotificationLabel(String str) {
        notificationLabel.setText(str);
    }

}
