package controller;

import model.HRModelStudent;
import view.HRView;
import view.HRViewAddWindow;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import model.HRModel;

/*
Assignment: HogwartsRoster
Group Members: Isaac Robles Jr. & Pablo Torres
ID: ixr5066
*/

public class HRController {
    HRModel mdl;
    HRView vw;
    HRViewAddWindow addWindow;
    private int currentID;
    private int indexOfItemClicked;
    private int listSize;
    
    public HRController() {
        mdl = new HRModel();
        vw = new HRView(mdl.getListOfStudents());
        vw.setVisible(true);
        addWindow = new HRViewAddWindow();
        listSize = mdl.getListOfStudents().size();
        currentID = mdl.getListOfStudents().size() + 1;
        System.out.println("currentID: " + currentID); //For debugging purposes
        indexOfItemClicked = -1;
        initButton();
        System.out.println("indexOfItemClicked: " +indexOfItemClicked); //For debugging purposes
    }
    
    /*
    The initButton() method initializes all the buttons and the event that should happen when they are clicked.
    */
    private void initButton() {
        vw.getAddButton().addActionListener(event -> add());
        vw.getEditButton().addActionListener(event -> edit());
        vw.getDeleteButton().addActionListener(event -> delete());
        vw.getExitButton().addActionListener(event -> exit());
        vw.getAllButton().addActionListener(event -> showAllTable());
        vw.getGButton().addActionListener(event -> showGTable());
        vw.getSButton().addActionListener(event -> showSTable());
        vw.getHButton().addActionListener(event -> showHTable());
        vw.getRButton().addActionListener(event -> showRTable());
        vw.getTable().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    indexOfItemClicked = vw.getTable().rowAtPoint(e.getPoint());
                    System.out.println("indexOfItemClicked: " + indexOfItemClicked); //For debugging purposes
                    
                } catch (ArrayIndexOutOfBoundsException a) {

                }
            }
        });
    }
    
    /*
    The add() method simply brings the HRViewAddWindow up and calls the addStudent() method.
    */
    public void add() {
        addWindow.setVisible(true);
        addWindow.getDoneButton().addActionListener(event -> addStudent());
    }
    
    /*
    The edit() method simply brings the HRViewAddWindow up and calls the editStudent() method.
    */
    public void edit() {
        if(indexOfItemClicked < 0) {
            System.out.println("Please click an item to edit"); //For debugging purposes
            vw.getLabel().setText("Please click an item to edit");
            System.out.println("indexOfItemClicked: " + indexOfItemClicked); //For debugging purposes
        }
        else if(indexOfItemClicked >= 0) {
            addWindow.setVisible(true);
            fillAddWindowText();
            addWindow.getDoneButton().addActionListener(event -> editStudent());
        }
    }
    
    /*
    The addStudent() method allows the user to add another entry into the database.
    The method does multiple check and try-catches to make sure the user is entering the apporpriate info.
    This method is called from the add() method.
    */
    private void addStudent() {
        try {
            //If there elements in the mdl, then the contents of this if statement will execute
            if(listSize > 0) {
                
                //This ensures that there can be no duplicate students
                if(mdl.allEntries(addWindow.getFirstNameText(), addWindow.getLastNameText(), 
                        addWindow.getHouseNameText(), addWindow.getYearText(), addWindow.getPointsNumText())) {
                    System.out.println("Item already exists"); //For debugging purposes
                }
                //See emptyTextChecker() below
                else if(emptyTextChecker()) {
                    addWindow.setNotificationLabel("Please fill out all fields"); //For debugging purposes
                }
                else {
                    //The try-catch is to ensure the user only enters integers into Points.
                    try {
                        //See houseTextChecker() below. Afterwards, the student is added, currentID is incremented, and other methods are executed.
                        if(houseTextChecker()) {
                            mdl.getListOfStudents().add(new HRModelStudent(currentID, addWindow.getFirstNameText(),
                                    addWindow.getLastNameText(), addWindow.getHouseNameText(), addWindow.getYearText(),
                                    Integer.parseInt(addWindow.getPointsNumText())));
                            houseAddChecker();
                            currentID++;
                            clearAddWindowText();
                            refreshStudentUI();
                            System.out.println("currentID: " + currentID); //For debugging purposes
                        }
                        else {
                            addWindow.setNotificationLabel("Please enter a correct house and with proper capitalization"); //For debugging purposes
                        }
                    }
                    catch(NumberFormatException e) {
                        addWindow.setNotificationLabel("Please only enter numbers into Points"); //For debugging purposes
                    }
                }
            }
            //If there are no elements in mdl, then the check for duplicates is skipped.
            else if(listSize <= 0) {
                //See emptyTextChecker() below
                if(emptyTextChecker()) {
                    addWindow.setNotificationLabel("Nothing to add"); //For debugging purposes
                }
                else {
                    //The try-catch is to ensure the user only enters integers into Points.
                    try {
                        //See houseTextChecker() below. Afterwards, the student is added, currentID is incremented, and other methods are executed.
                        if(houseTextChecker()) {
                            mdl.getListOfStudents().add(new HRModelStudent(currentID, addWindow.getFirstNameText(),
                                    addWindow.getLastNameText(), addWindow.getHouseNameText(), addWindow.getYearText(),
                                    Integer.parseInt(addWindow.getPointsNumText())));
                            houseAddChecker();
                            currentID++;
                            clearAddWindowText();
                            refreshStudentUI();
                            System.out.println("currentID: " + currentID);
                        }
                        else {
                            addWindow.setNotificationLabel("Please enter a correct house and with proper capitalization"); //For debugging purposes
                        }
                    }
                    catch(NumberFormatException e) {
                        addWindow.setNotificationLabel("Please only enter numbers into Points"); //For debugging purposes
                    }
                }
            }
        }
        catch(ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException"); 
        }
    }
    
    /*
    The editStudent() method allows the user to edit an entry that already exist in the database.
    The method does multiple check and try-catches to make sure the user is entering the apporpriate info.
    This method is called from the edit() method.
    */
    private void editStudent() {
        //See emptyTextChecker() below.
        if(emptyTextChecker()) {
            addWindow.setNotificationLabel("Please fill out all fields"); //For debugging purposes
        }
        else {
            //The try-catch is to ensure the user only enters integers into Points.
            try {
                /*
                See houseTextChecker() below. Afterwards, the student is added, currentID is incremented, and other methods are executed.
                The student is added in front of the index we are editting and deleting the student in the index we selected.
                This ensures no duplicated.
                */
                if(houseTextChecker()) {
                    mdl.getListOfStudents().add(indexOfItemClicked,
                            new HRModelStudent(mdl.getListOfStudents().get(indexOfItemClicked).getStudentID(),
                            addWindow.getFirstNameText(), addWindow.getLastNameText(), addWindow.getHouseNameText(), addWindow.getYearText(),
                            Integer.parseInt(addWindow.getPointsNumText())));
                    mdl.getListOfStudents().remove(indexOfItemClicked + 1);
                    houseEditChecker();
                    clearAddWindowText();
                    refreshStudentUI();
                    System.out.println("currentID: " + currentID);
                }
                else {
                    addWindow.setNotificationLabel("Please enter a correct house and with proper capitalization"); //For debugging purposes
                }
            }
            catch(NumberFormatException e) {
                addWindow.setNotificationLabel("Please only enter numbers into Points"); //For debugging purposes
            }
        }
    }
    
    /*
    The delete() method allows the user to delete an entry from the database.
    The method does multiple checks to ensure that the has selected something to delete, or that there is anything to delete.
    This method is called when the delete button from HRView is clicked on.
    */
    private void delete() {
        //If there are entries to delete, the code in this if-statement will execute.
        if(listSize > 0) {
            //If there are entries to delete, but the user has not clicked an item to delete, then this code will execute.
            if(indexOfItemClicked < 0) {
                System.out.println("Please click an item to be deleted first"); //For debugging purposes
                vw.getLabel().setText("Please click an item to be deleted first");
                System.out.println("indexOfItemClicked: " + indexOfItemClicked); //For debugging purposes
            }
            //If there are entries to delete and the user has not clicked an item to delete, then a student will be deleted.
            //The user needs to click another student to delete again.
            else if(indexOfItemClicked >= 0 && indexOfItemClicked <= mdl.getListOfStudents().size() - 1) {
                mdl.getListOfStudents().remove(indexOfItemClicked);
                indexOfItemClicked = -1;
                refreshStudentUI();
                System.out.println("indexOfItemClicked: " + indexOfItemClicked); //For debugging purposes
            }
        }
        //If there are no entries to delete, this code will execute.
        else if(listSize <= 0) {
            System.out.println("Nothing to delete"); //For debugging purposes
            System.out.println("indexOfItemClicked: " + indexOfItemClicked); //For debugging purposes
        }
    }
    
    /*
    The refreshStudentUI() method refreshes the entire main window to let the table update as well.
    This is only called when the table updates.
    This method is called from the addStudent() and editStudent().
    */
    private void refreshStudentUI() {
        vw.setVisible(false);
        vw.setVisible(true);
    }
    
    /*
    The clearAddWindowText() simply hides the HRViewAddWindow and clears the text from any text fields.
    The method was created to reduce clutter.
    This method is called from the addStudent() and editStudent() method.
    */
    private void clearAddWindowText() {
        addWindow.setVisible(false);
        addWindow.setFirstNameText("");
        addWindow.setLastNameText("");
        addWindow.setHouseNameText("");
        addWindow.setYearText("");
        addWindow.setPointsNumText("");
    }
    
    /*
    The fillAddWindowText() method add the infomation of the index to be editted into the appropriate text boxes in HRViewAddWindow.
    The method was created to reduce clutter.
    This method is called from the edit() method.
    */
    private void fillAddWindowText() {
        addWindow.setFirstNameText(mdl.getListOfStudents().get(indexOfItemClicked).getfName());
        addWindow.setLastNameText(mdl.getListOfStudents().get(indexOfItemClicked).getlName());
        addWindow.setHouseNameText(mdl.getListOfStudents().get(indexOfItemClicked).getHouse());
        addWindow.setYearText(mdl.getListOfStudents().get(indexOfItemClicked).getYear());
        addWindow.setPointsNumText(Integer.toString(mdl.getListOfStudents().get(indexOfItemClicked).getPointsContributed()));
    }
    
    /*
    The houseTextChecker() method was created to reduce the clutter in the if statements during logic checking.
    The method checks if the text entered for the house is a correct house name and is capitalized correctly.
    The method is called from editStudent() and addDtudent().
    */
    private boolean houseTextChecker() {
        boolean correctHouse = addWindow.getHouseNameText().equals("Gryffindor") || addWindow.getHouseNameText().equals("Slytherin")
                        || addWindow.getHouseNameText().equals("Hufflepuff") || addWindow.getHouseNameText().equals("Ravenclaw");
        
        return correctHouse;
    }
    
    /*
    The emptyTextChecker() method was created to reduce the clutter in the if statements during logic checking.
    The method check if the any text boxes are empty.
    The method is called from editStudent() and addStudent().
    */
    private boolean emptyTextChecker() {
        boolean filledText = (addWindow.getFirstNameText().equalsIgnoreCase("") || addWindow.getLastNameText().equalsIgnoreCase("") 
                || addWindow.getHouseNameText().equalsIgnoreCase("") || addWindow.getYearText().equalsIgnoreCase("") 
                || addWindow.getPointsNumText().equalsIgnoreCase(""));
        
        return filledText;
    }
    
    private void houseAddChecker() {
        if(addWindow.getHouseNameText().equals("Gryffindor")) {
            mdl.getListOfGStudents().add(new HRModelStudent(currentID, addWindow.getFirstNameText(),
                    addWindow.getLastNameText(), addWindow.getHouseNameText(), addWindow.getYearText(),
                    Integer.parseInt(addWindow.getPointsNumText())));
        }
        else if(addWindow.getHouseNameText().equals("Slytherin")) {
            mdl.getListOfSStudents().add(new HRModelStudent(currentID, addWindow.getFirstNameText(),
                    addWindow.getLastNameText(), addWindow.getHouseNameText(), addWindow.getYearText(),
                    Integer.parseInt(addWindow.getPointsNumText())));
        }
        else if(addWindow.getHouseNameText().equals("Hufflepuff")) {
            mdl.getListOfHStudents().add(new HRModelStudent(currentID, addWindow.getFirstNameText(),
                    addWindow.getLastNameText(), addWindow.getHouseNameText(), addWindow.getYearText(),
                    Integer.parseInt(addWindow.getPointsNumText())));
        }
        else if(addWindow.getHouseNameText().equals("Ravenclaw")) {
            mdl.getListOfRStudents().add(new HRModelStudent(currentID, addWindow.getFirstNameText(),
                    addWindow.getLastNameText(), addWindow.getHouseNameText(), addWindow.getYearText(),
                    Integer.parseInt(addWindow.getPointsNumText())));
        }
    }
    
    private void houseEditChecker() {
        boolean studentFound = false;
        int i = 0;
        
        if(addWindow.getHouseNameText().equals("Gryffindor")) {
            while(!studentFound) {
                if(mdl.getListOfStudents().get(indexOfItemClicked).getStudentID() == mdl.getListOfGStudents().get(i).getStudentID()) {
                    studentFound = true;
                }
                else {
                    i++;
                }
            }
            if(studentFound) {
                mdl.getListOfGStudents().add(i,
                        new HRModelStudent(mdl.getListOfStudents().get(indexOfItemClicked).getStudentID(),
                                addWindow.getFirstNameText(), addWindow.getLastNameText(), addWindow.getHouseNameText(), addWindow.getYearText(),
                                Integer.parseInt(addWindow.getPointsNumText())));
                mdl.getListOfGStudents().remove(i + 1);
            }
        }
        else if(addWindow.getHouseNameText().equals("Slytherin")) {
            System.out.println("Student is Slytherin");
            while(!studentFound) {
                if(mdl.getListOfStudents().get(indexOfItemClicked).getStudentID() == mdl.getListOfSStudents().get(i).getStudentID()) {
                    studentFound = true;
                    System.out.println("Student found is now true");
                }
                else {
                    i++;
                    System.out.println("i has been interated to: " + i);
                }
            }
            if(studentFound) {
                System.out.println("Before adding. i is now: " + i);
                mdl.getListOfSStudents().add(i,
                        new HRModelStudent(mdl.getListOfStudents().get(indexOfItemClicked).getStudentID(),
                                addWindow.getFirstNameText(), addWindow.getLastNameText(), addWindow.getHouseNameText(), addWindow.getYearText(),
                                Integer.parseInt(addWindow.getPointsNumText())));
                System.out.println("After adding and before removing");
                mdl.getListOfSStudents().remove(i + 1);
                System.out.println("After removing");
            }
        }
        else if(addWindow.getHouseNameText().equals("Hufflepuff")) {
            while(!studentFound) {
                if(mdl.getListOfStudents().get(indexOfItemClicked).getStudentID() == mdl.getListOfHStudents().get(i).getStudentID()) {
                    studentFound = true;
                }
                else {
                    i++;
                }
            }
            if(studentFound) {
                mdl.getListOfHStudents().add(i,
                        new HRModelStudent(mdl.getListOfStudents().get(indexOfItemClicked).getStudentID(),
                                addWindow.getFirstNameText(), addWindow.getLastNameText(), addWindow.getHouseNameText(), addWindow.getYearText(),
                                Integer.parseInt(addWindow.getPointsNumText())));
                mdl.getListOfHStudents().remove(i + 1);
            }
        }
        else if(addWindow.getHouseNameText().equals("Ravenclaw")) {
            while(!studentFound) {
                if(mdl.getListOfStudents().get(indexOfItemClicked).getStudentID() == mdl.getListOfRStudents().get(i).getStudentID()) {
                    studentFound = true;
                }
                else {
                    i++;
                }
            }
            if(studentFound) {
                mdl.getListOfRStudents().add(i,
                        new HRModelStudent(mdl.getListOfStudents().get(indexOfItemClicked).getStudentID(),
                                addWindow.getFirstNameText(), addWindow.getLastNameText(), addWindow.getHouseNameText(), addWindow.getYearText(),
                                Integer.parseInt(addWindow.getPointsNumText())));
                mdl.getListOfRStudents().remove(i + 1);
            }
        }
    }
    
    private void showAllTable() {
        indexOfItemClicked = -1;
        System.out.println("indexOfItemClicked: " + indexOfItemClicked);
        vw.setVisible(false);
        vw = new HRView(mdl.getListOfStudents());
        initButton();
        vw.setVisible(true);
    }
    
    private void showGTable() {
        indexOfItemClicked = -1;
        System.out.println("indexOfItemClicked: " + indexOfItemClicked);
        vw.setVisible(false);
        vw = new HRView(mdl.getListOfGStudents());
        initButton();
        vw.setVisible(true);
    }
    
    private void showSTable() {
        indexOfItemClicked = -1;
        System.out.println("indexOfItemClicked: " + indexOfItemClicked);
        vw.setVisible(false);
        vw = new HRView(mdl.getListOfSStudents());
        initButton();
        vw.setVisible(true);
    }
    
    private void showHTable() {
        indexOfItemClicked = -1;
        System.out.println("indexOfItemClicked: " + indexOfItemClicked);
        vw.setVisible(false);
        vw = new HRView(mdl.getListOfHStudents());
        initButton();
        vw.setVisible(true);
    }
    
    private void showRTable() {
        indexOfItemClicked = -1;
        System.out.println("indexOfItemClicked: " + indexOfItemClicked);
        vw.setVisible(false);
        vw = new HRView(mdl.getListOfRStudents());
        initButton();
        vw.setVisible(true);
    }
    
    /*
    The exit() method allows the exit button to close the program when clicking the exit button.
    */
    private void exit() {
        System.exit(0);
    }
}