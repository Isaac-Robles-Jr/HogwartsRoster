package hogwartsroster;

/*
Assignment: HogwartsRoster
Group Members: Isaac Robles Jr. & Pablo Torres
ID: ixr5066
*/

import java.util.ArrayList;

public class HRModel {
    
    private final ArrayList<HRModelStudent> studentList;
    
    public HRModel() {
        studentList = new ArrayList<>();
        addStudentsToList();
    }
    
    /*
    The addStudentsToList() method puts some default entries in to populate the database.
    */
    private void addStudentsToList() {
        getListOfStudents().add(new HRModelStudent(1, "Harry", "Potter", "Gryffindor", "7th", 12));
        getListOfStudents().add(new HRModelStudent(2, "Harry", "Potter", "Slytherin", "7th", 12));
        getListOfStudents().add(new HRModelStudent(3, "Harry", "Potter", "Hufflepuff", "7th", 12));
        getListOfStudents().add(new HRModelStudent(4, "Harry", "Potter", "Ravenclaw", "7th", 12));
    }
    
    /*
    The getListOfStudents() method simply returns the studentList to allow the use of studentList's methods
    */
    public ArrayList<HRModelStudent> getListOfStudents() {
        return studentList;
    }
    
    /*
    The allEntries() method takes in the JTextFields from the addWindow and checks to see if that entry exists in studentList.
    */
    public boolean allEntries(String fName, String lName, String house, String year, String points) {
        for(int i = 0; i < studentList.size() - 1; i++) {
            if((fName.equalsIgnoreCase(studentList.get(i).getfName())
                    && lName.equalsIgnoreCase(studentList.get(i).getlName()) 
                    && house.equalsIgnoreCase(studentList.get(i).getHouse())
                    && year.equalsIgnoreCase(studentList.get(i).getYear())
                    && points.equalsIgnoreCase(Integer.toString(studentList.get(i).getPointsContributed()))) == true) {
                return true;
            }
        }
        
        return false;
    }
}