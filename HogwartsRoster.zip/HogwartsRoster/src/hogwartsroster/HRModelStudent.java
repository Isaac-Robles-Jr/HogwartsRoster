package hogwartsroster;

/*
Assignment: HogwartsRoster
Group Members: Isaac Robles Jr. & Pablo Torres
ID: ixr5066
*/

public class HRModelStudent {
    int studentID;
    String fName;
    String lName;
    String house;
    String year;
    int pointsContributed;

    public HRModelStudent(int studentID, String fName, String lName, String house, String year, int pointsContributed) {
        this.studentID = studentID;
        this.fName = fName;
        this.lName = lName;
        this.house = house;
        this.year = year;
        this.pointsContributed = pointsContributed;
    }

    public int getStudentID() {
        return studentID;
    }

    public String getfName() {
        return fName;
    }

    public String getlName() {
        return lName;
    }

    public String getHouse() {
        return house;
    }

    public String getYear() {
        return year;
    }

    public int getPointsContributed() {
        return pointsContributed;
    }
}