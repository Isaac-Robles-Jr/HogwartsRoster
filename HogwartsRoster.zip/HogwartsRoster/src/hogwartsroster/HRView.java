package hogwartsroster;

/*
Assignment: HogwartsRoster
Group Members: Isaac Robles Jr. & Pablo Torres
ID: ixr5066
*/

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class HRView extends JFrame {
    
    //Icon variables
    private final ImageIcon gIcon = new ImageIcon("src/resources/Gryffindor.jpg");
    private final ImageIcon sIcon = new ImageIcon("src/resources/Slytherin.jpg");
    private final ImageIcon hIcon = new ImageIcon("src/resources/Hufflepuff.jpg");
    private final ImageIcon rIcon = new ImageIcon("src/resources/Ravenclaw.jpg");
    
    //Button variables
    private final JButton gButton = new JButton(gIcon);
    private final JButton sButton = new JButton(sIcon);
    private final JButton hButton = new JButton(hIcon); 
    private final JButton rButton = new JButton(rIcon);
    private final JButton addButton = new JButton("Add");
    private final JButton editButton = new JButton("Edit");
    private final JButton deleteButton = new JButton("Delete");
    private final JButton exitButton = new JButton("Exit");
    
    //Table and ScrollPane variables
    private final JTable studentTable;
    private final JScrollPane scrollTable;
    
    //Panel variables
    private final JPanel studentPanel;
    private final JPanel topButtonPanel;
    private final JPanel botButtonPanel;
    
    public HRView(ArrayList<HRModelStudent> studentList) {
        setTitle("Hogwarts Roster");
        setSize(700, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        topButtonPanel = new JPanel(new FlowLayout());
        topButtonPanel.add(gButton);
        topButtonPanel.add(sButton);
        topButtonPanel.add(hButton);
        topButtonPanel.add(rButton);
        
        studentTable = new JTable(new HRModelStudentTable(studentList));
        studentTable.setPreferredScrollableViewportSize(new Dimension(450, 50));
        studentTable.setFillsViewportHeight(true);
        
        scrollTable = new JScrollPane(studentTable);
        scrollTable.setVisible(true);
        scrollTable.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        add(scrollTable);
        
        studentPanel = new JPanel(new BorderLayout());
        studentPanel.add(scrollTable);
        
        botButtonPanel = new JPanel(new FlowLayout());
        botButtonPanel.add(addButton);
        botButtonPanel.add(editButton);
        botButtonPanel.add(deleteButton);
        botButtonPanel.add(exitButton);
        
        setContentPane(new JPanel(new BorderLayout()));
        getContentPane().add(topButtonPanel, BorderLayout.NORTH);
        getContentPane().add(studentPanel, BorderLayout.CENTER);
        getContentPane().add(botButtonPanel, BorderLayout.SOUTH);
        setResizable(false);
    }

    public JButton getAddButton() {
        return addButton;
    }

    public JButton getEditButton() {
        return editButton;
    }

    public JButton getDeleteButton() {
        return deleteButton;
    }

    public JButton getExitButton() {
        return exitButton;
    }
    
    public JTable getTable() {
        return studentTable;
    }
}