package model;

/*
Assignment: HogwartsRoster
Group Members: Isaac Robles Jr. & Pablo Torres
ID: ixr5066
 */
import java.util.ArrayList;

public class HRModel {

    private final ArrayList<HRModelStudent> allStudentsList;
    private final ArrayList<HRModelStudent> studentGList;
    private final ArrayList<HRModelStudent> studentSList;
    private final ArrayList<HRModelStudent> studentHList;
    private final ArrayList<HRModelStudent> studentRList;

    public HRModel() {
        allStudentsList = new ArrayList<>();
        studentGList = new ArrayList<>();
        studentSList = new ArrayList<>();
        studentHList = new ArrayList<>();
        studentRList = new ArrayList<>();
        addStudentsToAllList();
        addStudentsToGList();
        addStudentsToSList();
        addStudentsToHList();
        addStudentsToRList();
    }

    /*
    The addStudentsToAllList() and similar methods put some default entries in to populate the database.
    The reason there are so many tables is due to the teams idea of allowing the user to separate the students by house.
    There is a method for all students and specific a house. These are designated at the first letter of the house instead of containing
    "All" in the method name.
     */
    private void addStudentsToAllList() {
        getListOfAllStudents().add(new HRModelStudent(1, "Harry", "Potter", "Gryffindor", "Alumni", 50));
        getListOfAllStudents().add(new HRModelStudent(2, "Hermione", "Granger", "Gryffindor", "Alumni", 60));
        getListOfAllStudents().add(new HRModelStudent(3, "Ron", "Weasley", "Gryffindor", "Alumni", 45));
        getListOfAllStudents().add(new HRModelStudent(4, "Draco", "Malfoy", "Slytherin", "Alumni", 10));
    }

    private void addStudentsToGList() {
        getListOfGStudents().add(new HRModelStudent(1, "Harry", "Potter", "Gryffindor", "Alumni", 50));
        getListOfGStudents().add(new HRModelStudent(2, "Hermione", "Granger", "Gryffindor", "Alumni", 60));
        getListOfGStudents().add(new HRModelStudent(3, "Ron", "Weasley", "Gryffindor", "Alumni", 45));
    }

    private void addStudentsToRList() {
        //getListOfSStudents().add(new HRModelStudent(2, "Harry", "Potter", "Slytherin", "7th", 12));
    }

    private void addStudentsToHList() {
        //getListOfHStudents().add(new HRModelStudent(3, "Harry", "Potter", "Hufflepuff", "7th", 12));
    }

    private void addStudentsToSList() {
        getListOfSStudents().add(new HRModelStudent(4, "Draco", "Malfoy", "Slytherin", "Alumni", 10));
    }

    /*
    The getListOfAllStudents() and similar methods simply returns the studentList to allow the use of studentList's methods.
    There is a method for all students and specific a house. These are designated at the first letter of the house instead of containing
    "All" in the method name.
     */
    public ArrayList<HRModelStudent> getListOfAllStudents() {
        return allStudentsList;
    }

    public ArrayList<HRModelStudent> getListOfGStudents() {
        return studentGList;
    }

    public ArrayList<HRModelStudent> getListOfSStudents() {
        return studentSList;
    }

    public ArrayList<HRModelStudent> getListOfHStudents() {
        return studentHList;
    }

    public ArrayList<HRModelStudent> getListOfRStudents() {
        return studentRList;
    }

    /*
    The allEntries() method takes in the JTextFields from the addWindow and checks to see if that entry exists in studentList.
     */
    public boolean allEntries(String fName, String lName, String house, String year, String points) {
        for (int i = 0; i < allStudentsList.size() - 1; i++) {
            if ((fName.equalsIgnoreCase(allStudentsList.get(i).getfName())
                    && lName.equalsIgnoreCase(allStudentsList.get(i).getlName())
                    && house.equalsIgnoreCase(allStudentsList.get(i).getHouse())
                    && year.equalsIgnoreCase(allStudentsList.get(i).getYear())
                    && points.equalsIgnoreCase(Integer.toString(allStudentsList.get(i).getPointsContributed()))) == true) {
                return true;
            }
        }

        return false;
    }
}
