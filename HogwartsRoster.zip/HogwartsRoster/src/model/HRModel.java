package model;



/*
Assignment: HogwartsRoster
Group Members: Isaac Robles Jr. & Pablo Torres
ID: ixr5066
*/

import java.util.ArrayList;

public class HRModel {
    
    private final ArrayList<HRModelStudent> studentList;
    private final ArrayList<HRModelStudent> studentGList;
    private final ArrayList<HRModelStudent> studentSList;
    private final ArrayList<HRModelStudent> studentHList;
    private final ArrayList<HRModelStudent> studentRList;
    
    public HRModel() {
        studentList = new ArrayList<>();
        studentGList = new ArrayList<>();
        studentSList = new ArrayList<>();
        studentHList = new ArrayList<>();
        studentRList = new ArrayList<>();
        addStudentsToList();
        addStudentsToGList();
        addStudentsToSList();
        addStudentsToHList();
        addStudentsToRList();
    }
    
    /*
    The addStudentsToList() method puts some default entries in to populate the database.
    */
    private void addStudentsToList() {
        getListOfStudents().add(new HRModelStudent(1, "Harry", "Potter", "Gryffindor", "7th", 12));
        getListOfStudents().add(new HRModelStudent(2, "Harry", "Potter", "Slytherin", "7th", 12));
        getListOfStudents().add(new HRModelStudent(3, "Harry", "Potter", "Hufflepuff", "7th", 12));
        getListOfStudents().add(new HRModelStudent(4, "Harry", "Potter", "Ravenclaw", "7th", 12));
    }
    
    private void addStudentsToGList() {
        getListOfGStudents().add(new HRModelStudent(1, "Harry", "Potter", "Gryffindor", "7th", 12));
    }
    
    private void addStudentsToSList() {
        getListOfSStudents().add(new HRModelStudent(2, "Harry", "Potter", "Slytherin", "7th", 12));
    }
    
    private void addStudentsToHList() {
        getListOfHStudents().add(new HRModelStudent(3, "Harry", "Potter", "Hufflepuff", "7th", 12));
    }
    
    private void addStudentsToRList() {
        getListOfRStudents().add(new HRModelStudent(4, "Harry", "Potter", "Ravenclaw", "7th", 12));
    }
    
    /*
    The getListOfStudents() method simply returns the studentList to allow the use of studentList's methods
    */
    public ArrayList<HRModelStudent> getListOfStudents() {
        return studentList;
    }
    
    public ArrayList<HRModelStudent> getListOfGStudents() {
        return studentGList;
    }
    
    public ArrayList<HRModelStudent> getListOfSStudents() {
        return studentSList;
    }
    
    public ArrayList<HRModelStudent> getListOfHStudents() {
        return studentHList;
    }
    
    public ArrayList<HRModelStudent> getListOfRStudents() {
        return studentRList;
    }
    
    /*
    The allEntries() method takes in the JTextFields from the addWindow and checks to see if that entry exists in studentList.
    */
    public boolean allEntries(String fName, String lName, String house, String year, String points) {
        for(int i = 0; i < studentList.size() - 1; i++) {
            if((fName.equalsIgnoreCase(studentList.get(i).getfName())
                    && lName.equalsIgnoreCase(studentList.get(i).getlName()) 
                    && house.equalsIgnoreCase(studentList.get(i).getHouse())
                    && year.equalsIgnoreCase(studentList.get(i).getYear())
                    && points.equalsIgnoreCase(Integer.toString(studentList.get(i).getPointsContributed()))) == true) {
                return true;
            }
        }
        
        return false;
    }
}