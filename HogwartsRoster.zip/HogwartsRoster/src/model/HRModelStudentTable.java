package model;

/*
Assignment: HogwartsRoster
Group Members: Isaac Robles Jr. & Pablo Torres
ID: ixr5066
 */
import model.HRModelStudent;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

public class HRModelStudentTable extends AbstractTableModel {

    private static final String[] COLUMN_NAMES = {"StudentID", "First Name", "Last Name", "House", "Year", "Points"};
    private final ArrayList<HRModelStudent> studentList;

    public HRModelStudentTable(ArrayList<HRModelStudent> studentList) {
        this.studentList = studentList;
        for (int i = 0; i < studentList.size() - 1; i++) {
            for (int j = 0; j < 6; j++) {
                if (j == 0) {
                    setValueAt(studentList.get(i).getStudentID(), j, i);
                } else if (j == 1) {
                    setValueAt(studentList.get(i).getfName(), j, i);
                } else if (j == 2) {
                    setValueAt(studentList.get(i).getlName(), j, i);
                } else if (j == 3) {
                    setValueAt(studentList.get(i).getHouse(), j, i);
                } else if (j == 4) {
                    setValueAt(studentList.get(i).getYear(), j, i);
                } else if (j == 5) {
                    setValueAt(studentList.get(i).getPointsContributed(), j, i);
                }
            }
        }
    }

    @Override
    public String getColumnName(int col) {
        return COLUMN_NAMES[col];
    }

    public void setValueAt(HRModelStudent aValue, int rowIndex, int columnIndex) {
        fireTableCellUpdated(rowIndex, columnIndex);
    }

    @Override
    public int getRowCount() {
        return studentList.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMN_NAMES.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if (columnIndex == 0) {
            return studentList.get(rowIndex).getStudentID();
        } else if (columnIndex == 1) {
            return studentList.get(rowIndex).getfName();
        } else if (columnIndex == 2) {
            return studentList.get(rowIndex).getlName();
        } else if (columnIndex == 3) {
            return studentList.get(rowIndex).getHouse();
        } else if (columnIndex == 4) {
            return studentList.get(rowIndex).getYear();
        } else if (columnIndex == 5) {
            return studentList.get(rowIndex).getPointsContributed();
        }

        return "Item does not exist";
    }
}
