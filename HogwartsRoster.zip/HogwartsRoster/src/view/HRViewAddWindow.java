package view;

/*
Assignment: HogwartsRoster
Group Members: Isaac Robles Jr. & Pablo Torres
ID: ixr5066
 */
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class HRViewAddWindow extends JFrame {

    //Panel variable
    private final JPanel studentPanel;
    private final JPanel botButtonPanel;

    //Button variable
    private final JButton doneButton;
    private final JButton sortButton;

    //TextField variables
    private final JTextField firstName = new JTextField(15);
    private final JTextField lastName = new JTextField(15);
    private final JTextField houseName = new JTextField(15);
    private final JTextField year = new JTextField(15);
    private final JTextField pointsNum = new JTextField(15);

    //Label variables
    private final JLabel notificationLabel = new JLabel();

    public HRViewAddWindow() {
        setTitle("Edit Window");
        setSize(750, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        doneButton = new JButton("Done");
        sortButton = new JButton("Sorting Hat");

        studentPanel = new JPanel(new GridLayout(6, 1));
        studentPanel.add(new JLabel("First Name"));
        studentPanel.add(firstName);
        studentPanel.add(new JLabel("Last Name"));
        studentPanel.add(lastName);
        studentPanel.add(new JLabel("House"));
        studentPanel.add(houseName);
        studentPanel.add(new JLabel("Year"));
        studentPanel.add(year);
        studentPanel.add(new JLabel("Points"));
        studentPanel.add(pointsNum);
        studentPanel.add(notificationLabel);

        botButtonPanel = new JPanel(new FlowLayout());
        botButtonPanel.add(sortButton);
        botButtonPanel.add(doneButton);

        setContentPane(new JPanel(new BorderLayout()));
        getContentPane().add(studentPanel, BorderLayout.CENTER);
        getContentPane().add(botButtonPanel, BorderLayout.SOUTH);
        setResizable(false);
    }

    public JButton getDoneButton() {
        return doneButton;
    }

    public JButton getSortButton() {
        return sortButton;
    }

    public String getFirstNameText() {
        return firstName.getText();
    }

    public void setFirstNameText(String str) {
        firstName.setText(str);
    }

    public String getLastNameText() {
        return lastName.getText();
    }

    public void setLastNameText(String str) {
        lastName.setText(str);
    }

    public String getHouseNameText() {
        return houseName.getText();
    }

    public void setHouseNameText(String str) {
        houseName.setText(str);
    }

    public String getYearText() {
        return year.getText();
    }

    public void setYearText(String str) {
        year.setText(str);
    }

    public String getPointsNumText() {
        return pointsNum.getText();
    }

    public void setPointsNumText(String str) {
        pointsNum.setText(str);
    }

    public void setNotificationLabel(String str) {
        notificationLabel.setText(str);
    }

}
